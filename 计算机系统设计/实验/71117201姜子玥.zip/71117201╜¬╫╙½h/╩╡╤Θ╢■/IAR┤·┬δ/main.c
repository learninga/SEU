#include <msp430f249.h>
//#include "io430.h"

char res_list[16] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};
void Output(int src)
{
  if (src>=0 && src<=15) P4OUT = ~res_list[src];
  else P4OUT = ~(0x40);
}
int scanline;
int location(void)
{
  int row=-1,col;
  int _code = P5IN>>4;
  switch(_code)
  {
    case 0xf:{return -1;}                 // no number
    case 0xe:{col = 0;break;}
    case 0xd:{col = 1;break;}
    case 0xb:{col = 2;break;}
    case 0x7:{col = 3;break;}
  }
  int _scan = scanline;
  while(_scan){row+=1;_scan>>=1;}
  return row+col*4;
}

int main( void )
{
  scanline = 1;
  P4DIR = 0x7f;
  P4OUT = 0xff;
  P5DIR = 0x0f;
  P5OUT = 0x00;
  Output(-1);
  WDTCTL = WDTPW + WDTHOLD;             // �رտ��Ź���ʹ�ü�����
  TA0CCTL0 = CCIE;                      // CCR0�ж�ʹ��
  TA0CCR0 = 6;
  TA0CTL = TASSEL_2 + MC_1;     // SMCLK, ������ģʽ, ���TAR������
  __bis_SR_register(LPM0_bits + GIE);  // ����LPM0,ʹ���ж�
}

// TA0�жϷ������
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    scanline  = scanline<<1;
    if(scanline==16) scanline = 1;
    P5OUT = ~scanline & 0x0f;
    int res  = location();
    if(res!=-1) Output(res);
}
