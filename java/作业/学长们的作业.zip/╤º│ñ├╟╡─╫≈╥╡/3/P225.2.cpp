#include<iostream>
#include"P225.2.h"
using namespace std;

void DblList::Insert(int v)
{
	if(first==NULL)
	{
		first=new DblListNode();
		first->data=v;
		first->left=first;
		first->right=first;
		last=first;
	}
	else
	{
		DblListNode* item=new DblListNode();
		item->data=v;
		item->left=last;
		item->right=last->right;
		last->right->left=item;
		last->right=item;
		last=item;
	}
}

void DblList::Output()
{
	DblListNode* current=first;
	do
	{
		cout<<current->data<<' ';
		current=current->right;
	}while(current!=first);
	cout<<endl;
}

void DblList::Concatenate(DblList m)
{
	if(m.first!=NULL)
	{
		first->left=m.last;
		last->right=m.first;
		m.first->left=last;
		m.last->right=first;
		last=m.last;
	}
}

int main()
{
	DblList n;
	n.Insert(1);
	n.Insert(2);
	n.Insert(3);
	cout<<"n: ";
	n.Output();
	DblList m;
	m.Insert(4);
	m.Insert(5);
	cout<<"m: ";
	m.Output();
	n.Concatenate(m);
	cout<<"n+m: ";
	n.Output();
	return 0;
}
