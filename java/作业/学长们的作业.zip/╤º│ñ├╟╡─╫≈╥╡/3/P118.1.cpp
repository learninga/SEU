#include<iostream>
#include<map>
#include"P118.1.h"
using namespace std;

String::String(char* c)
{
	length=0;
	while(c[length++]!='\0');
	str=new char[--length];
	for(int i=0;i<length;i++)
		str[i]=c[i];
}

void String::Frequency()
{
	map<char,int> m;
	for(int i=0;i<length;i++)
		m[str[i]]++;
	for(map<char,int>::iterator i=m.begin();i!=m.end();i++)
		cout<<i->first<<": "<<i->second<<"\t"<<i->second/(float)length<<endl;
}

int main()
{
	String s("abcdabcdef");
	s.Frequency();
	
	return 0;
}