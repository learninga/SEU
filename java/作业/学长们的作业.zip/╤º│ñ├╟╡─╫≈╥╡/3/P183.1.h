#include <iostream>

#ifndef CHAIN_H
#define CHAIN_H

class Chain;

class ChainNode
{
public:
	friend class Chain;
	ChainNode(int d=0):data(d),link(NULL){}
private:
	int data;
	ChainNode *link;
};

class Chain
{
public:
	Chain(){first=0;}
	void Add(int v);
	int Length();
private:
	ChainNode *first;
};

#endif