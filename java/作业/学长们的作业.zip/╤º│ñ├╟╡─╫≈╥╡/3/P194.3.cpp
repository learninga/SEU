#include<iostream>
#include"P194.3.h"
using namespace std;

void Chain::Add(int v)
{
	if(first==NULL)
	{
		first=new ChainNode(v);
		last=first;
	}
	else
	{
		ChainNode* item=new ChainNode(v);
		last->link=item;
		last=item;
	}
	length++;
}

ostream& operator<<(ostream& out,Chain& c)
{
	ChainNode* current=c.first;
	while(current!=NULL)
	{
		out<<current->data<<' ';
		current=current->link;
	}
	return out;
}

void Chain::IntoArray(int* a)
{
	int *temp=new int[length];
	ChainNode* current=first;
	for(int i=0;i<length;i++)
	{
		temp[i]=current->data;
		current=current->link;
	}
	copy(temp,temp+length,a);
	delete[] temp;
}

int main()
{
	Chain c;
	c.Add(1);
	c.Add(2);
	c.Add(3);
	c.Add(4);
	c.Add(5);
	int arr[5];
	c.IntoArray(arr);
	cout<<"Array: ";
	for(int i=0;i<5;i++)
		cout<<arr[i]<<' ';
	cout<<endl;
	return 0;
}
