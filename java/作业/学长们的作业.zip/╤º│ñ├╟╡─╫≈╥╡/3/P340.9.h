#include<iostream>
using namespace std;

#ifndef GRAPH_H
#define GRAPH_H

class AdjMatrix
{
public:
	AdjMatrix(int n);
	void InsertEdge(int a,int b);
	int GetNum()
	{return num;}
	int** GetAll()
	{return all;}
	~AdjMatrix()
	{delete[] all;};
private:
	int** all;
	int num;
};

class Node
{
public:
	Node():vertex(0),next(NULL){}
	void SetVertex(int v)
	{vertex=v;}
	void SetNext(Node* n)
	{next=n;}
	Node* GetNext()
	{return next;}
private:
	int vertex;
	Node* next;
};

class AdjList
{
public:
	AdjList(AdjMatrix &a);
private:
	Node** all;
};

#endif