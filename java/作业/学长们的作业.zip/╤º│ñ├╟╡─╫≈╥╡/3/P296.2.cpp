#include <iostream>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include "P296.2.h"
using namespace std;

void f(int n)
{
	BinarySearchTree<int,int> tree;
	for(int i=0;i<n;i++)
	{
		int item=rand();
		tree.Insert(make_pair(item,item));
	}
	int h=tree.GetHeight();
	double result=h/(log((double)n)/log((double)2));
	cout<<"Result for "<<n<<": "<<result<<endl;
}

int main()
{
	srand(time(NULL));
	f(100);
	f(500);
	for(int i=1000;i<=10000;i+=1000)
		f(i);
	return 0;
}