#include <iostream>
#include "P372.1.h"
using namespace std;

AdjList::AdjList(int n)
{
	num=n;
	all=new Node*[n];
	for(int i=0;i<n;i++)
		all[i]=NULL;
	visited=new bool[n];
	fill(visited,visited+n,false);
}

void AdjList::InsertEdge(int a,int b,int l)
{
	Node* current=all[a];
	if(current!=NULL)
	{
		while(current->GetNext()!=NULL)
			current=current->GetNext();
		current->SetNext(new Node());
		Node* next=current->GetNext();
		next->SetVertex(b);
		next->SetLength(l);
	}
	else
	{
		all[a]=new Node();
		all[a]->SetVertex(b);
		all[a]->SetLength(l);
	}
	
	current=all[b];
	if(current!=NULL)
	{
		while(current->GetNext()!=NULL)
			current=current->GetNext();
		current->SetNext(new Node());
		Node* next=current->GetNext();
		next->SetVertex(a);
		next->SetLength(l);
	}
	else
	{
		all[b]=new Node();
		all[b]->SetVertex(a);
		all[b]->SetLength(l);
	}
}

void AdjList::Output()
{
	for(int i=0;i<num;i++)
	{
		Node* current=all[i];
		while(current!=NULL)
		{
			cout<<current->GetVertex()<<' ';
			current=current->GetNext();
		}
		cout<<endl;
	}
}

int times=0;
void AdjList::ShortestLengths(int v,int l)
{
	visited[v]=true;
	times++;
	cout<<"times:"<<times<<endl;
	Node* current=all[v];
	while(current!=NULL)
	{
		int w=current->GetVertex();
		if(!visited[w])
		{
			int newlength=l+current->GetLength();
			cout<<w<<' '<<"Length: "<<newlength<<endl;
			ShortestLengths(w,newlength);
		}
		current=current->GetNext();
	}
}

AdjList::~AdjList()
{
	delete[] all;
	delete[] visited;
}

int main()
{
	AdjList l(7);
	l.InsertEdge(0,1,1);
	l.InsertEdge(0,2,2);
	l.InsertEdge(1,3,3);
	l.InsertEdge(1,4,4);
	l.InsertEdge(2,5,5);
	l.InsertEdge(2,6,6);
	l.ShortestLengths(1,0);
	return 0;
}