#include <iostream>
using namespace std;

void Insert(const int& e,int *a,int i)
{
	a[0]=e;
	while(e<a[i])
	{
		a[i+1]=a[i];
		i--;
	}
	a[i+1]=e;
}

void InsertionSort(int *a,const int n)
{
	for(int j=2;j<=n;j++)
	{
		int temp=a[j];
		Insert(temp,a,j-1);
		for(int i=1;i<n+1;i++)
			cout<<a[i]<<' ';
		cout<<endl;
	}
}

int main()
{
	int nums[15]={0,12,2,16,30,8,28,4,10,20,6,18};
	InsertionSort(nums,11);
	return 0;
}