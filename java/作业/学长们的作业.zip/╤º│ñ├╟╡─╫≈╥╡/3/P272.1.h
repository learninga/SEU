#include<iostream>
#include<stack>
using namespace std;

#ifndef TREE_H
#define TREE_H

class Tree;

class TreeNode
{
	friend class Tree;
public:
	TreeNode(int d):data(d),leftChild(NULL),rightChild(NULL){}
	void SetLeft(TreeNode* t);
	void SetRight(TreeNode* t);
	TreeNode* GetLeft();
	TreeNode* GetRight();
private:
	int data;
	TreeNode *leftChild;
	TreeNode *rightChild;
};

class Tree
{
public:
	Tree(TreeNode* n):root(n){}
	TreeNode* GetRoot();
	void Count();
	void Visit(TreeNode* n);
private:
	TreeNode *root;
};

#endif