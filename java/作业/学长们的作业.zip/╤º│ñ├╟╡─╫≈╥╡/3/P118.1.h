#include <iostream>

#ifndef STRING_H
#define STRING_H

class String
{
public:
	String(char* c);
	~String()
	{delete[] str;}
	void Frequency();
private:
	char* str;
	int length;
};

#endif