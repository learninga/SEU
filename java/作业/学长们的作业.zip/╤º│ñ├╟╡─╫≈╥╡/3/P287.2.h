#include<iostream>
#include<map>
using namespace std;

#ifndef MINPQ_H
#define MINPQ_H

class MinPQ
{
public:
	virtual ~MinPQ(){}
	virtual bool IsEmpty() const=0;
	virtual const int& Top() const=0;
	virtual void Push(const int&)=0;
	virtual void Pop()=0;
};

class MinHeap:public MinPQ
{
public:
	MinHeap(int theCapacity=10);
	~MinHeap();
	bool IsEmpty() const;
	const int& Top() const;
	void ChangeSize1D(int* &a, const int oldSize,const int newSize);
	void Push(const int& v);
	void Pop();
	void Output();
private:
	int* heap;
	int heapSize;
	int capacity;
};

#endif