#include <iostream>
#include "P273.4.h"
using namespace std;

void TreeNode::SetLeft(TreeNode* t)
{
	leftChild=t;
}

void TreeNode::SetRight(TreeNode* t)
{
	rightChild=t;
}

TreeNode* TreeNode::GetLeft()
{
	return leftChild;
}

TreeNode* TreeNode::GetRight()
{
	return rightChild;
}

TreeNode* Tree::GetRoot()
{
	return root;
}

void Tree::Delete(TreeNode* n)
{		
	if(!n->GetLeft() && !n->GetRight())
		return;
	if(n->GetLeft())
		Delete(n->GetLeft());
	if(n->GetRight())
		Delete(n->GetRight());
	delete n;
}

int main()
{
	Tree t(new TreeNode(2));
	TreeNode* root=t.GetRoot();
	root->SetLeft(new TreeNode(1));
	root->SetRight(new TreeNode(3));
	TreeNode* l=root->GetLeft();
	l->SetLeft(new TreeNode(4));
	l->SetRight(new TreeNode(5));
	t.Delete(root);
	return 0;
}