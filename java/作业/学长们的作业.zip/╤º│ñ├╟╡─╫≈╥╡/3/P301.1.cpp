#include <iostream>
#include <cmath>
#include "P301.1.h"
using namespace std;

WinnerTree::WinnerTree(int* all,int n)
{
	bottom=new Node*[n];
	for(int i=0;i<n;i++)
		bottom[i]=new Node(all[i],NULL,NULL,NULL);
	int times=log((float)n)/log(2.0f);
	height=times+1;
	Node** down=bottom;
	for(int i=0;i<times;i++)
	{
		Node** up=new Node*[(int)pow(2.0f,(float)(times-i-1))]();
		for(int j=0;j<(int)pow(2.0f,(float)(times-i-1));j++)
		{
			up[j]=new Node();
			up[j]->data=min(down[2*j]->data,down[2*j+1]->data);
			up[j]->left=down[2*j];
			up[j]->right=down[2*j+1];
			down[2*j]->parent=up[j];
			down[2*j+1]->parent=up[j];
		}
		down=up;
		if(i==times-1)
			root=up[0];
	}
}

void WinnerTree::Delete(Node* n)
{
	 if (n != NULL)
	 {                        
		 Delete(n->left);    
		 Delete(n->right);    
		 delete n;
	 }
}

WinnerTree::~WinnerTree()
{
	Delete(root);
}

LoserTree::LoserTree(WinnerTree &t)
{
	Switch(t.GetRoot(),root,NULL);

}

void LoserTree::Switch(Node* oldtree, Node* &newtree,Node* parent)
{
	if(oldtree->left!= NULL)
	{                        
		newtree = new Node();
		int data=max(oldtree->left->data,oldtree->right->data);
		newtree->data = data;
		newtree->parent=parent;
		Switch(oldtree->left, newtree->left,oldtree);
		Switch(oldtree->right,newtree->right,oldtree);
	}
	else
	{
		newtree = new Node();
		newtree->data = oldtree->data;
		newtree->parent=parent;
	}
}

int main()
{
	int all[]={10,9,20,6,8,9,90,17};
	WinnerTree win(all,8);
	LoserTree lose(win);
	return 0;
}