#include<iostream>
#include<map>
using namespace std;

#ifndef BSTREE_H
#define BSTREE_H

template<class K,class E>
class BinarySearchTree;

template<class K,class E>
class TreeNode
{
	friend class BinarySearchTree<K,E>;
public:
	TreeNode(pair<K,E> d):data(d),leftChild(NULL),rightChild(NULL){}
private:
	pair<K,E> data;
	TreeNode *leftChild;
	TreeNode *rightChild;
};

template<class K,class E>
class BinarySearchTree
{
public:
	BinarySearchTree():root(NULL){}
	void Insert(const pair<K,E>& thePair)
	{
		TreeNode<K,E> *p=root,*pp=0;
		while(p)
		{
			pp=p;
			if(thePair.first<p->data.first)
				p=p->leftChild;
			else if(thePair.first>p->data.first)
				p=p->rightChild;
			else
			{
				p->data.second=thePair.second;
				return;
			}
		}
		p=new TreeNode<K,E>(thePair);
		if(root)
			if(thePair.first<pp->data.first)
				pp->leftChild=p;
			else
				pp->rightChild=p;
		else
			root=p;
	}
	TreeNode<K,E>* Get(const K& key)
	{
		TreeNode<K,E> *currentNode=root;
		while(currentNode)
		{
			if(key!=currentNode->data.first)
				previousNode=currentNode;
			if(key<currentNode->data.first)
				currentNode=currentNode->leftChild;
			else if(key>currentNode->data.first)
				currentNode=currentNode->rightChild;
			else
				return currentNode;
		}
		return NULL;
	}
	void Delete(const K& key)
	{
		TreeNode<K,E> *target=Get(key);
		if(!target)
			cout<<"No such key!"<<endl;
		else
		{
			TreeNode<K,E> *l=target->leftChild;
			TreeNode<K,E> *r=target->rightChild;
			if(!l && !r)
			{
				previousNode->leftChild== target ? previousNode->leftChild=NULL : previousNode->rightChild=NULL;
				delete target;
			}
			else if((!l && r) || (l && !r))
			{
				TreeNode<K,E> *child;
				l!=NULL ? child=l : child=r;
				previousNode->leftChild==target ? previousNode->leftChild=child : previousNode->rightChild=child;
				delete target;
			}
			else
			{
				TreeNode<K,E> *father;
				while(l->rightChild)
				{
					father=l;
					l=l->rightChild;
				}
				l->rightChild=target->rightChild;
				previousNode->leftChild==target ? previousNode->leftChild=l : previousNode->rightChild=l;
				delete target;
			}
		}
	}
private:
	TreeNode<K,E>* root;
	TreeNode<K,E>* previousNode;
};

#endif