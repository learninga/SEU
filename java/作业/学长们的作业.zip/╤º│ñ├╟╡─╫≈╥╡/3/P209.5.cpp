#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <cmath>
#include "P209.5.h"
using namespace std;

Polynomial::Polynomial()
{
	header=NULL;
	last=NULL;
}

ostream& operator<<(ostream& is,Polynomial& x)
{
	Node* current=x.header;
	is<<current->coef;
	if(current->exp==1)
		is<<'x';
	else if(current->exp!=0)
		is<<'x'<<'^'<<current->exp;
	current=current->link;
	while (current!=x.header)
	{
		if(current->coef>0)
			is<<" + ";
		else
			is<<" - ";
		if(current->coef!=1 && current->coef !=-1)
		{
			if(current->coef>0)
				is<<current->coef;
			else
				is<<-current->coef;
		}
		if(current->exp==1)
			is<<'x';
		else if(current->exp!=0)
			is<<'x'<<'^'<<current->exp;
		current=current->link;
	}
	is<<endl;
	return is;
}

istream& operator>>(istream& is,Polynomial& x)
{
	string all;
	is>>all;
	all.push_back('\0');
	string temp;
	vector<int> vec;
	for(string::iterator i=all.begin();i!=all.end();i++)
	{
		if(*i==',' || *i=='\0')
		{
			int d=atoi(temp.c_str());
			vec.push_back(d);
			temp.clear();
			continue;
		}
		temp.push_back(*i);
	}
	if(vec[0]*2!=vec.size()-1)
	{
		cout<<"Input error!"<<endl;
		return is;
	}
	for(int i=0;i<vec[0];i++)
	{
		int coef=vec[2*i+1];
		int exp=vec[2*i+2];
		x.InsertBack(coef,exp);
	}
	return is;
}

void Polynomial::InsertBack(int coef,int exp)
{
	if(header==NULL)
	{
		header=new Node(coef,exp);
		header->link=header;
		last=header;
	}
	else
	{
		Node* item=new Node(coef,exp);
		last->link=item;
		item->link=header;
		last=item;
	}
}

Polynomial::Polynomial(const Polynomial& a)
{
	header=a.header;
	last=a.last;
}

const Polynomial& Polynomial::operator=(const Polynomial& a)
{
	header=a.header;
	last=a.last;
	return *this;
}

Polynomial Polynomial::operator+(const Polynomial& b)
{
	Node* ai=header;
	Node* bi=b.header;
	Polynomial c;
	bool flaga=false;
	bool flagb=false;
	while(1)
	{
		if((ai==header && flaga) || (bi==b.header && flagb))
			break;
		if(ai->exp==bi->exp)
		{
			int sum=ai->coef+bi->coef;
			if(sum)
				c.InsertBack(sum,ai->exp);
			ai=ai->link;
			bi=bi->link;
			flaga=true;
			flagb=true;
		}
		else if(ai->exp<bi->exp)
		{
			c.InsertBack(bi->coef,bi->exp);
			bi=bi->link;
			flagb=true;
		}
		else
		{
			c.InsertBack(ai->coef,ai->exp);
			ai=ai->link;
			flaga=true;
		}
	}
	if(!flaga)
	{
		c.InsertBack(ai->coef,ai->exp);
		ai=ai->link;
	}
	while(ai!=header)
	{
		c.InsertBack(ai->coef,ai->exp);
		ai=ai->link;
	}
	if(!flagb)
	{
		c.InsertBack(bi->coef,bi->exp);
		bi=bi->link;
	}
	while(bi!=b.header)
	{
		c.InsertBack(bi->coef,bi->exp);
		bi=bi->link;
	}
	return c;
}

Polynomial Polynomial::operator -(const Polynomial &b)
{
	Node* ai=header;
	Node* bi=b.header;
	Polynomial c;
	do
	{
		if(ai->exp==bi->exp)
		{
			int sum=ai->coef-bi->coef;
			if(sum)
				c.InsertBack(sum,ai->exp);
			ai=ai->link;
			bi=bi->link;
		}
		else if(ai->exp<bi->exp)
		{
			c.InsertBack(-bi->coef,bi->exp);
			bi=bi->link;
		}
		else
		{
			c.InsertBack(ai->coef,ai->exp);
			ai=ai->link;
		}
	}while(ai->link==header || bi->link==b.header);
	while(ai!=header)
	{
		c.InsertBack(ai->coef,ai->exp);
		ai=ai->link;
	}
	while(bi!=b.header)
	{
		c.InsertBack(-bi->coef,bi->exp);
		bi=bi->link;
	}
	return c;
}

Polynomial Polynomial::operator*(const Polynomial& b)
{
	Polynomial c;
	Node* bi=b.header;
	do 
	{
		Polynomial temp;
		Node* ai=header;
		do 
		{
			int coef=ai->coef*bi->coef;
			int exp=ai->exp+bi->exp;
			temp.InsertBack(coef,exp);
			ai=ai->link;
		} while (ai!=header);
		if(c.header==NULL)
			c=temp;
		else
		{
			Polynomial d=c+temp;
			c=d;
		}
		bi=bi->link;
	} while (bi!=b.header);
	return c;
}

float Polynomial::Evaluate(float x)const
{
	float result=0;
	Node* current=header;
	do 
	{
		result+=current->coef*pow(x,current->exp);
		current=current->link;
	} while (current!=header);
	return result;
}

int main()
{
	cout<<"Input a polynomial(a): "<<endl;
	Polynomial a;
	cin>>a;
	cout<<"Input a polynomial(b): "<<endl;
	Polynomial b;
	cin>>b;
	Polynomial c;
	cout<<"a + b = ";
	cout<<a+b;
	cout<<"a - b = ";
	cout<<a-b;
	cout<<"a * b = ";
	cout<<a*b;
	cout<<"a(3) = "<<a.Evaluate(3)<<endl;
	return 0;
}