#include <iostream>
#include <list>
using namespace std;

int Get(list<int>& l,int n)
{
	list<int>::iterator iter=l.begin();
	for(int i=0;i<n;i++)
		iter++;
	return *iter;
}

void Change(list<int>& l,int i)
{
	list<int>::iterator iter=l.begin();
	for(int j=0;j<i;j++)
		iter++;
	list<int>::iterator temp=iter;
	temp++;
	*temp=*iter;
}

void Set(list<int>& l,int index,int n)
{
	list<int>::iterator iter=l.begin();
	for(int i=0;i<index;i++)
		iter++;
	*iter=n;
}

void Insert(const int& e,list<int>& l,int i)
{
	list<int>::iterator iter=l.begin();
	*iter=e;
	while(e<Get(l,i))
	{
		Change(l,i);
		i--;
	}
	Set(l,i+1,e);
}

void Output(list<int>& l,int start,int end)
{
	int count=0;
	for(list<int>::iterator i=l.begin();i!=l.end();i++)
	{
		if(count>=start)
			cout<<*i<<' ';
		if(count>=end-1)
		{
			cout<<endl;
			break;
		}
		count++;
	}
}

void InsertionSort(list<int>& l,const int n)
{
	list<int>::iterator iter=l.begin();
	for(int j=2;j<=n;j++)
	{
		int temp=Get(l,j);
		Insert(temp,l,j-1);
		Output(l,1,n+1);
	}
}

int main()
{
	int nums[15]={0,12,2,16,30,8,28,4,10,20,6,18};
	list<int> l(nums,nums+15);
	InsertionSort(l,11);
	return 0;
}