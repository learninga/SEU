#include <iostream>
#include <queue>
#include "P352.5.h"
using namespace std;

AdjList::AdjList(int n)
{
	num=n;
	all=new Node*[n];
	for(int i=0;i<n;i++)
		all[i]=NULL;
}

void AdjList::InsertEdge(int a,int b)
{
	Node* current=all[a];
	if(current!=NULL)
	{
		while(current->GetNext()!=NULL)
			current=current->GetNext();
		current->SetNext(new Node());
		Node* next=current->GetNext();
		next->SetVertex(b);
	}
	else
	{
		all[a]=new Node();
		all[a]->SetVertex(b);
	}
}

void AdjList::BFS(int v)
{
	visited=new bool[num];
	fill(visited,visited+num,false);
	visited[v]=true;
	queue<int> q;
	q.push(v);
	while(!q.empty())
	{
		v=q.front();
		q.pop();
		Node* current=all[v];
		while(current!=NULL)
		{
			int w=current->GetVertex();
			if(!visited[w])
			{
				q.push(w);
				visited[w]=true;
			}
			current=current->GetNext();
		}
	}
	delete[] visited;
}

int main()
{
	AdjList l(4);
	l.InsertEdge(0,1);
	l.InsertEdge(1,2);
	l.InsertEdge(2,0);
	l.InsertEdge(0,3);
	l.InsertEdge(3,2);
	l.BFS(0);
	return 0;
}