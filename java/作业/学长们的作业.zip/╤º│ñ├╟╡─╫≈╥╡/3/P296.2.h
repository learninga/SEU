#include<iostream>
#include<map>
using namespace std;

#ifndef BSTREE_H
#define BSTREE_H

template<class K,class E>
class BinarySearchTree;

template<class K,class E>
class TreeNode
{
	friend class BinarySearchTree<K,E>;
public:
	TreeNode(pair<K,E> d):data(d),leftChild(NULL),rightChild(NULL){}
private:
	pair<K,E> data;
	TreeNode *leftChild;
	TreeNode *rightChild;
};

template<class K,class E>
class BinarySearchTree
{
public:
	BinarySearchTree():root(NULL){}
	void Insert(const pair<K,E>& thePair)
	{
		TreeNode<K,E> *p=root,*pp=0;
		int count=0;
		while(p)
		{
			pp=p;
			count++;
			if(thePair.first<p->data.first)
				p=p->leftChild;
			else if(thePair.first>p->data.first)
				p=p->rightChild;
			else
			{
				p->data.second=thePair.second;
				return;
			}
		}
		p=new TreeNode<K,E>(thePair);
		if(root)
			if(thePair.first<pp->data.first)
				pp->leftChild=p;
			else
				pp->rightChild=p;
		else
			root=p;
		if(count>height)
			height=count;
	}
	int GetHeight()
	{
		return height;
	}
private:
	TreeNode<K,E>* root;
	int height;
};

#endif