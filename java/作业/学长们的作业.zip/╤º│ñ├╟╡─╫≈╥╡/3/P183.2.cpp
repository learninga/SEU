#include<iostream>
#include"P183.2.h"
using namespace std;

void Chain::Add(int v)
{
	if(first==NULL)
		first=new ChainNode(v);
	else
	{
		ChainNode* last=first;
		while(last->link!=NULL)
			last=last->link;
		last->link=new ChainNode(v);
	}
}

int Chain::Length()
{
	int count=0;
	ChainNode* last=first;
	while(last!=NULL)
	{
			last=last->link;
			count++;
	}
	return count;
}

void Chain::Delete(ChainNode* c)
{
	if(c==first)
		first=first->link;
	else
	{
		ChainNode* before=first;
		while(before->link!=c)
			before=before->link;
		before->link=c->link;
		delete c;
	}
}

ChainNode* Chain::Find(int v)
{
	ChainNode* target=first;
	while(target->data!=v)
			target=target->link;
	return target;
}

ostream& operator<<(ostream& out,Chain& c)
{
	ChainNode* current=c.first;
	while(current!=NULL)
	{
		out<<current->data<<' ';
		current=current->link;
	}
	return out;
}

int main()
{
	Chain c;
	c.Add(1);
	c.Add(2);
	c.Add(3);
	c.Add(4);
	c.Add(5);
	cout<<"Before delete: "<<c<<endl;
	c.Delete(c.Find(3));
	c.Delete(c.Find(1));
	cout<<"After delete: "<<c<<endl;
	return 0;
}
