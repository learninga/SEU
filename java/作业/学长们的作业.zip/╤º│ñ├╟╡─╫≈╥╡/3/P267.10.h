#include<iostream>
#include<stack>
#include<queue>
using namespace std;

#ifndef TREE_H
#define TREE_H

template <class T>
class BinaryTree;
template <class T>
class InorderIterator;
template <class T>
class PreorderIterator;
template <class T>
class PostorderIterator;
template <class T>
class LevelorderIterator;

template <class T>
class TreeNode
{
	friend class BinaryTree<T>;
	friend class InorderIterator<T>;
	friend class PreorderIterator<T>;
	friend class PostorderIterator<T>;
	friend class LevelorderIterator<T>;
public:
	TreeNode(T d):data(d),leftChild(NULL),rightChild(NULL){}
	void SetLeft(TreeNode<T>* t)
	{leftChild=t;}
	void SetRight(TreeNode<T>* t)
	{rightChild=t;}
private:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
};

template <class T>
class InorderIterator
{
public:
	InorderIterator(TreeNode<T>* c):currentNode(c){};
	T Get(T* n)
	{return *n;}
	T* Next()
	{
		while(currentNode)
		{
			s.push(currentNode);
			currentNode=currentNode->leftChild;
		}
		if(s.empty())
			return 0;
		currentNode=s.top();
		s.pop();
		T& temp=currentNode->data;
		currentNode=currentNode->rightChild;
		return &temp;
	}
private:
	TreeNode<T>* currentNode;
	stack<TreeNode<T>*> s;
};

template <class T>
class PreorderIterator
{
public:
	PreorderIterator(TreeNode<T>* c):currentNode(c){};
	T Get(T* n)
	{return *n;}
	T* Next()
	{
		static bool start=false;
		if(!start)
		{
			s.push(currentNode);
			start=true;
		}
		if(!s.empty())  
		{  
			currentNode = s.top();  
			T& temp=currentNode->data;
			s.pop();  
			if(currentNode->rightChild)  
				s.push(currentNode->rightChild);  
			if(currentNode->leftChild)  
				s.push(currentNode->leftChild);
			return &temp;
		}
		else
			return 0;	
	}
private:
	TreeNode<T>* currentNode;
	stack<TreeNode<T>*> s;
};

template <class T>
class PostorderIterator
{
public:
	PostorderIterator(TreeNode<T>* c):currentNode(c){};
	T Get(T* n)
	{return *n;}
	T* Next()
	{
				static bool start=false;
		if(!start)
		{
			s.push(currentNode);
			start=true;
		}
		if(!s.empty())  
		{  
			if(currentNode->rightChild)  
				s.push(currentNode->rightChild);  
			if(currentNode->leftChild)  
				s.push(currentNode->leftChild);
			currentNode = s.top();  
			T& temp=currentNode->data;
			s.pop();  
			return &temp;
		}
		else
			return 0;	
	}
private:
	TreeNode<T>* currentNode;
	stack<TreeNode<T>*> s;
};

template <class T>
class LevelorderIterator
{
public:
	LevelorderIterator(TreeNode<T>* c):currentNode(c){};
	T Get(T* n)
	{return *n;}
	T* Next()
	{
		if(currentNode)
		{
			T& temp=currentNode->data;
			if(currentNode->leftChild)
				q.push(currentNode->leftChild);
			if(currentNode->rightChild)
				q.push(currentNode->rightChild);
			if(!q.empty())
			{
				currentNode=q.front();
				q.pop();
			}
			else
				currentNode=NULL;
			return &temp;
		}
		else
			return 0;
	}
private:
	TreeNode<T>* currentNode;
	queue<TreeNode<T>*> q;
};

template <class T>
class BinaryTree
{
public:
	BinaryTree():root(NULL){}
	BinaryTree(TreeNode<T> *n):root(n){}
	BinaryTree(BinaryTree<T>& t)
	{root=t.root;}
	TreeNode<T>* GetRoot()
	{return root;}
	void Delete(TreeNode<T>* n)
	{
		if(!n->leftChild && !n->rightChild)
		{
			delete n;
			return;
		}
		if(n->leftChild)
			Delete(n->leftChild);
		if(n->rightChild)
			Delete(n->rightChild);
		delete n;
	}
	~BinaryTree()
	{Delete(root);}
	bool IsEmpty()
	{return root==NULL;}
	BinaryTree(BinaryTree& bt1,T& item,BinaryTree<T>& bt2)
	{
		root->leftChild=bt1.root;
		root->rightChild=bt2.root;
		root->data=item;
	}
	BinaryTree<T> LeftSubtree()
	{
		BinaryTree t(root->leftChild);
		return t;
	}
	BinaryTree<T> RightSubtree()
	{
		BinaryTree t(root->rightChild);
		return t;
	}
	T RootData()
	{return root->data;}
private:
	TreeNode<T> *root;
};

#endif