#include <iostream>
#include <ctime>
#include "P272.1.h"
using namespace std;

void TreeNode::SetLeft(TreeNode* t)
{
	leftChild=t;
}

void TreeNode::SetRight(TreeNode* t)
{
	rightChild=t;
}

TreeNode* TreeNode::GetLeft()
{
	return leftChild;
}

TreeNode* TreeNode::GetRight()
{
	return rightChild;
}

TreeNode* Tree::GetRoot()
{
	return root;
}

void Tree::Visit(TreeNode* n)
{
	cout<<n->data<<endl;
}

void Tree::Count()
{
	stack<TreeNode*> s;
	TreeNode *currentNode=root;
	int count=0;
	while(1)
	{
		while(currentNode)
		{
			s.push(currentNode);
			currentNode=currentNode->leftChild;
		}
		if(s.empty())
		{
			//cout<<"The number of leaf node: "<<count<<endl;
			return;
		}
		currentNode=s.top();
		s.pop();
		if(currentNode->leftChild==NULL && currentNode->rightChild==NULL)
			count++;
		currentNode=currentNode->rightChild;
	}
}

int main()
{
	Tree t(new TreeNode(2));
	TreeNode* root=t.GetRoot();
	root->SetLeft(new TreeNode(1));
	root->SetRight(new TreeNode(3));
	TreeNode* l=root->GetLeft();
	l->SetLeft(new TreeNode(4));
	l->SetRight(new TreeNode(5));
	clock_t start=clock();
	for(int i=0;i<100000;i++)
		t.Count();
	clock_t end=clock();
	cout<<"Run 100000 times for "<<end-start<<"ms"<<endl;
	cout<<"Averge: "<<(float)(end-start)/100000<<"ms"<<endl;
	return 0;
}