#include<iostream>
using namespace std;

#ifndef GRAPH_H
#define GRAPH_H

class Node
{
public:
	Node():vertex(0),next(NULL){}
	void SetVertex(int v)
	{vertex=v;}
	void SetNext(Node* n)
	{next=n;}
	void SetLength(int l)
	{length=l;}
	Node* GetNext()
	{return next;}
	int GetVertex()
	{return vertex;}
	int GetLength()
	{return length;}
private:
	int vertex;
	int length;
	Node* next;
};

class AdjList
{
public:
	AdjList(int n);
	void InsertEdge(int a,int b,int l);
	void Output();
	void ShortestLengths(int v,int l);
	~AdjList();
private:
	Node** all;
	int num;
	bool* visited;
};

#endif