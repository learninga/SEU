#include <iostream>
#include <ctime>
#include <cstdlib>
#include "P316.3.h"
using namespace std;

Sets::Sets(int numberOfElements)
{
	if(numberOfElements<2)
		throw "Must have at least 2 elements";
	n=numberOfElements;
	parent=new int[n];
	fill(parent,parent+n,-1);
}

void Sets::SimpleUnion(int i,int j)
{
	parent[i]=j;
}

int Sets::SimpleFind(int i)
{
	while(parent[i]>=0)
		i=parent[i];
	return i;
}

void Sets::WeightedUnion(int i,int j)
{
	int temp=parent[i]+parent[j];
	if(parent[i]>parent[j])
	{
		parent[i]=j;
		parent[j]=temp;
	}
	else
	{
		parent[j]=i;
		parent[i]=temp;
	}
}

int Sets::CollapsingFind(int i)
{
	int r=0;
	for(r=i;parent[r]>=0;r=parent[r]);
	while(i!=r)
	{
		int s=parent[i];
		parent[i]=r;
		i=s;
	}
	return r;
}

int main()
{
	srand(time(NULL));
	Sets s1(10);
	Sets s2(10);
	int n1[]={-1,4,-1,2,-1,2,0,0,0,4};
	int n2[]={-1,4,-1,2,-1,2,0,0,0,4};
	s1.SetParent(n1);
	s2.SetParent(n2);
	time_t start1=clock();
	for(int i=0;i<5000000;i++)
	{
		int a=rand()%9;
		if(a==0 || a== 2 || a==4)
			continue;
		s1.SimpleUnion(a,a+1);
		int f1=s1.SimpleFind(0);
	}
	time_t end1=clock();
	time_t t1=end1-start1;
	time_t start2=clock();
	for(int i=0;i<5000000;i++)
	{
		int a=rand()%9;
		if(a==0 || a== 2 || a==4)
			continue;
		s2.WeightedUnion(a,a+1);
		int f2=s2.CollapsingFind(0);
	}
	time_t end2=clock();
	time_t t2=end2-start2;
	cout<<"SimpleUnion and SimpleFind take time(ms): "<<t1<<endl;
	cout<<"WeightedUnion and CollapsingFind take time(ms): "<<t2<<endl;
	return 0;
}