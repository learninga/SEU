#include <iostream>
#include "P296.1.h"
using namespace std;

int main()
{
	BinarySearchTree<int,int> tree;
	tree.Insert(make_pair(4,4));
	tree.Insert(make_pair(2,2));
	tree.Insert(make_pair(5,5));
	tree.Insert(make_pair(1,1));
	tree.Insert(make_pair(3,3));
	tree.Insert(make_pair(7,7));
	tree.Insert(make_pair(6,6));
	tree.Delete(8);
	tree.Delete(6);
	tree.Delete(5);
	tree.Delete(2);
	return 0;
}