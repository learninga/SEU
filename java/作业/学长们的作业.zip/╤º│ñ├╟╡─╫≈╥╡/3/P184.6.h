#include <iostream>

#ifndef CHAIN_H
#define CHAIN_H

class Chain;

class ChainNode
{
public:
	friend class Chain;
	ChainNode(int d=0):data(d),link(NULL){}
private:
	int data;
	ChainNode *link;
};

class Chain
{
public:
	Chain(){l=0;r=0;}
	void AddLeft(int v);
	void AddRight(int v);
	int Length();
	void MoveToRight(int n);
	void MoveToLeft(int n);
private:
	ChainNode *l;
	ChainNode *r;
};

#endif