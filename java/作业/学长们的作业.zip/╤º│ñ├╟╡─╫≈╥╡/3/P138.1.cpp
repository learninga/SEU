#include<iostream>
#include"P138.1.h"
using namespace std;

template <class T>
Stack<T>::Stack(int stackCapacity):capacity(stackCapacity)
{
	if(capacity<1)
		throw "Stack capacity must be >0";
	stack=new T[capacity];
	top=-1;
}

template <class T>
void Stack<T>::Push(const T& x)
{
	if(top==capacity-1)
	{
		ChangeSizeID(stack,capacity,2*capacity);
		capacity*=2;
	}
	stack[++top]=x;
}

template <class T>
void Stack<T>::Pop()
{
	if(IsEmpty())
		throw "Stack is empty. Cannot delete.";
	stack[top--].~T();
}

template <class T>
void Stack<T>::ChangeSizeID(T* &a,const int oldSize,const int newSize)
{
	if(newSize<0)
		throw "New length must be >=0";
	T* temp=new T[newSize];
	int number=min(oldSize,newSize);
	copy(a,a+number,temp);
	delete[] a;
	a=temp;
}

template <class T>
void Stack<T>::Output()
{
	for(int i=0;i<=top;i++)
		cout<<stack[i]<<' ';
	cout<<endl;
}

template <class T>
void Stack<T>::Split(Stack &a,Stack &b)
{
	int mid=top/2;
	if(!a.IsEmpty())
	{
		delete[] a.stack;
		a.stack=new T[capacity];
		a.top=-1;
	}
	if(!b.IsEmpty())
	{
		delete[] b.stack;
		b.stack=new T[capacity];
		b.top=-1;
	}
	for(int i=0;i<mid;i++)
		a.Push(stack[i]);
	for(int i=mid;i<=top;i++)
		b.Push(stack[i]);
}

template <class T>
void Stack<T>::Combine(Stack &a,Stack &b)
{
	if(!IsEmpty())
	{
		delete[] stack;
		stack=new T[capacity];
		top=-1;
	}
	for(int i=0;i<=a.top;i++)
		Push(a.stack[i]);
	for(int i=0;i<=b.top;i++)
		Push(b.stack[i]);
}

int main()
{
	Stack<int> a;
	a.Push(1);
	a.Push(2);
	a.Push(3);
	Stack<int> b;
	b.Push(4);
	b.Push(5);
	cout<<"a: ";
	a.Output();
	cout<<"b: ";
	b.Output();
	Stack<int> c;
	c.Combine(a,b);
	cout<<"Combine a,b into c: ";
	c.Output();
	c.Split(b,a);
	cout<<"Combine c into b,a: "<<endl;
	cout<<"a: ";
	a.Output();
	cout<<"b: ";
	b.Output();
	return 0;
}