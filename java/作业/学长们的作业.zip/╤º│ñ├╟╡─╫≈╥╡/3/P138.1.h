#include <iostream>

#ifndef STACK_H
#define STACK_H

template <class T>
class Stack
{
public:
	Stack(int stackCapacity=10);
	~Stack()
	{delete[] stack;}
	bool IsEmpty() const
	{return top==-1;}
	T& Top() const
	{
		if(IsEmpty())
			throw "Stack is empty";
		return stack[top];
	}
	void Push(const T& item);
	void Pop();
	void ChangeSizeID(T* &a,const int oldSize,const int newSize);
	void Output();
	void Split(Stack &a,Stack &b);
	void Combine(Stack &a,Stack &b);
private:
	T* stack;
	int top;
	int capacity;
};

#endif