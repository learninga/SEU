#include <iostream>

#ifndef CHAIN_H
#define CHAIN_H

class Chain;

class ChainNode
{
	friend std::ostream& operator<<(std::ostream&,Chain&);
public:
	friend class Chain;
	ChainNode(int d=0):data(d),link(NULL){}
private:
	int data;
	ChainNode *link;
};

class Chain
{
	friend std::ostream& operator<<(std::ostream&,Chain&);
public:
	Chain(){first=0;length=0;}
	void Add(int v);
	int Compute();
private:
	ChainNode *first;
	ChainNode *last;
	int length;
};

#endif