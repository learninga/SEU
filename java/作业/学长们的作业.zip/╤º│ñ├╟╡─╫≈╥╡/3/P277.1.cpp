#include <iostream>
#include "P277.1.h"
using namespace std;

void ThreadedNode::SetLeft(ThreadedNode* t)
{
	leftChild=t;
}

void ThreadedNode::SetRight(ThreadedNode* t)
{
	rightChild=t;
}

ThreadedNode* ThreadedNode::GetLeft()
{
	return leftChild;
}

ThreadedNode* ThreadedNode::GetRight()
{
	return rightChild;
}

ThreadedNode* ThreadedTree::GetRoot()
{
	return root;
}

ThreadedNode* ThreadedTree::InorderSucc(ThreadedNode* r)
{
	ThreadedNode *current=r;
	ThreadedNode *temp=current->rightChild;
	if(!current->rightThread)
		while(!temp->leftThread)
			temp=temp->leftChild;
	current=temp;
	if(current==root)
		return NULL;
	else
		return current;
}

void ThreadedTree::InsertLeft(ThreadedNode *s,ThreadedNode *r)
{
	r->leftChild=s->leftChild;
	r->leftThread=s->leftThread;
	r->rightChild=s;
	r->rightThread=true;
	s->leftChild=r;
	s->leftThread=false;
	if(!r->leftThread)
	{
		ThreadedNode *temp=InorderSucc(r);
		temp->rightChild=r;
	}
}

int main()
{
	ThreadedTree t(new ThreadedNode(2));
	ThreadedNode* root=t.GetRoot();
	t.InsertLeft(root,new ThreadedNode(1));	
	return 0;
}