#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;

int imove[8];
int jmove[8];

void initialmove()
{
	imove[0]=-1;
	imove[1]=0;
	imove[2]=1;
	imove[3]=1;
	imove[4]=1;
	imove[5]=0;
	imove[6]=-1;
	imove[7]=-1;

	jmove[0]=1;
	jmove[1]=1;
	jmove[2]=1;
	jmove[3]=0;
	jmove[4]=-1;
	jmove[5]=-1;
	jmove[6]=-1;
	jmove[7]=0;
}

bool isfinished(int** array,int n,int m)
{
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			if(array[i][j]==0)
				return false;
	return true;
}

void search(int** array,int ibug,int jbug,int n,int m)
{
	int count=0;
	while(!isfinished(array,n,m))
	{
		int choice=rand()%8;
		int dx=imove[choice];
		int dy=jmove[choice];
		int inext=ibug+dx;
		int jnext=jbug+dy;
		if(inext>=0 && inext<n && jnext>=0 && jnext<m && array[inext][jnext]<50000)
		{
			ibug=inext;
			jbug=jnext;
			array[ibug][jbug]++;
		}
	}
	cout<<"Finished!"<<endl;
	cout<<"Legal count: "<<count<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
			cout<<array[i][j]<<setw(4);
		cout<<endl;
	}
}

void run(int n,int m,int x,int y)
{
	int ibug=x;
	int jbug=y;
	int** array=new int*[n];
	for(int i=0;i<n;i++)
		array[i]=new int[m];
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			array[i][j]=0;
	array[ibug][jbug]++;
	search(array,ibug,jbug,n,m);
	delete[] array;
}

int main()
{
	int n=15;
	int m=15;
	srand(time(NULL));
	initialmove();
	time_t start=0;
	time_t end=0;
	start=clock();
	run(n,m,0,0);
	end=clock();
	cout<<"Time of "<<n<<'*'<<m<<": "<<end-start<<"ms"<<endl;
	return 0;
}