#include <iostream>
#include "P340.9.h"
using namespace std;

AdjMatrix::AdjMatrix(int n)
{
	num=n;
	all=new int*[n];
	for(int i=0;i<n;i++)
	{
		all[i]=new int[n];
		fill(all[i],all[i]+n,0);
	}
}

void AdjMatrix::InsertEdge(int a,int b)
{
	all[a][b]=1;
}

AdjList::AdjList(AdjMatrix &a)
{
	int n=a.GetNum();
	all=new Node*[n];
	for(int i=0;i<n;i++)
		all[i]=NULL;
	int** a_all=a.GetAll();
	for(int i=0;i<n;i++)
	{
		int count=0;
		Node* previous=NULL;
		for(int j=0;j<n;j++)
			if(a_all[i][j]==1)
				if(all[i]==NULL)
				{
					all[i]=new Node();
					all[i]->SetVertex(j);
					previous=all[i];
				}
				else
				{
					previous->SetNext(new Node());
					Node* next=previous->GetNext();
					next->SetVertex(j);
					previous=next;
				}
	}
}

int main()
{
	AdjMatrix m(3);
	m.InsertEdge(0,1);
	m.InsertEdge(1,2);
	AdjList l(m);
	return 0;
}