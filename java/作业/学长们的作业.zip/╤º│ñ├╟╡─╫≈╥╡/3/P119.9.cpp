#include<iostream>
#include<map>
#include<ctime>
#include"P119.9.h"
using namespace std;

String::String(char* c)
{
	length=0;
	while(c[length++]!='\0');
	str=new char[length];
	f=new int[--length];
	for(int i=0;i<length;i++)
		str[i]=c[i];
	str[length]='\0';
}

void String::Frequency()
{
	map<char,int> m;
	for(int i=0;i<length;i++)
		m[str[i]]++;
	for(map<char,int>::iterator i=m.begin();i!=m.end();i++)
		cout<<i->first<<": "<<i->second<<"\t"<<i->second/(float)length<<endl;
}

void String::FailureFunction()
{
	f[0]=-1;
	for (int j=1; j<length; j++) 
	{
		int i=f[j-1];
		while ((*(str+j)!=*(str+i+1)) && (i>=0) && str[i+1]!=str[j+1]) 
			i=f[i];
		*(str+j)==*(str+i+1) ? f[j]=i+1 : f[j]=-1;
	}
}

void String::FailureFunction2()
{
	f[0]=-1;
	for (int j=1; j<length; j++) 
	{
		int i=f[j-1];
		while ((*(str+j)!=*(str+i+1)) && (i>=0)) 
			i=f[i];
		*(str+j)==*(str+i+1) ? f[j]=i+1 : f[j]=-1;
	}
}

int String::FastFind(String &pat)
{
	int posP=0,posS=0;
	int lengthP=pat.length;
	while((posP<lengthP) && (posS<length))
		if(pat.str[posP]==str[posS])
		{
			posP++;
			posS++;
		}
		else
			if(posP==0)
				posS++;
			else
				posP=pat.f[posP-1]+1;
	if(posP<lengthP)
		return -1;
	else
		return posS-lengthP;
}

const int times=10000000;
void f(String &s,char* target,int flag)
{
	time_t start,stop;
	time(&start);
	for(int i=0;i<times;i++)
	{
		String pat(target);
		if(flag==1)
			pat.FailureFunction();
		else if(flag==2)
			pat.FailureFunction2();
		s.FastFind(pat);
	}
	time(&stop);
	time_t totalTime=stop-start;
	float runTime=(float)(totalTime)/times;
	cout<<totalTime<<'\t'<<runTime<<endl;
}

int main()
{
	String s1("abcabcacab");
	s1.FailureFunction();
	String s2("abcabcacab");
	s2.FailureFunction2();
	cout<<"totalTime\trunTime"<<endl;
	f(s1,"ac",1);
	f(s2,"ac",2);
	cout<<"Each one runs for "<<times<<" times."<<endl;
	return 0;
}