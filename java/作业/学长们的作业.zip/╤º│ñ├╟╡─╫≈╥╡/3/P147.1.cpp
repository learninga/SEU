#include<iostream>
#include"P147.1.h"
using namespace std;

template<class T>
Queue<T>::Queue(int queueCapacity):capacity(queueCapacity)
{
	if(capacity<1)
		throw "Queue capacity must be >0";
	queue=new T[capacity];
	front=rear=0;
	lastOp=pop;
}

template<class T>
void Queue<T>::Push(const T& x)
{
	if(IsFull())
	{
		T* newQueue= new T[2*capacity];
		int start=(front)%capacity;
		if(start<2)
			copy(queue+start,queue+start+capacity,newQueue);
		else
		{
			copy(queue+start,queue+capacity,newQueue);
			copy(queue,queue+rear+1,newQueue+capacity-start);
		}
		//front=2*capacity-1;
		rear=capacity;
		capacity*=2;
		delete[] queue;
		queue=newQueue;
	}
	queue[rear]=x;
	rear=(rear+1)%capacity;
	lastOp=push;
}

template<class T>
void Queue<T>::Pop()
{
	if(IsEmpty())
		throw "Queue is empty. Cannot delete.";
	queue[front].~T();
	front=(front+1)%capacity;
	lastOp=pop;
}

template<class T>
void Queue<T>::Output()
{
	if(front<rear)
	{
		if(!IsEmpty() && !IsFull())
			for(int i=front;i!=rear;i=(i++)%capacity)
				cout<<queue[i]<<' ';
		else if(IsFull())
			for(int i=front;i!=capacity;i=(i++)%capacity)
				cout<<queue[i]<<' ';
		else
			cout<<"The queue is empty!";
	}
	else
	{
		for(int i=front;i!=capacity;i=(i++)%capacity)
				cout<<queue[i]<<' ';
		for(int i=0;i!=rear;i=(i++)%capacity)
				cout<<queue[i]<<' ';
	}
	cout<<endl;
}

int main()
{
	Queue<int> q;
	for(int i=1;i<=10;i++)
	{
		q.Push(i);
		q.Output();
	}
	q.Pop();
	q.Output();
	q.Pop();
	q.Output();
	q.Push(11);
	q.Output();
	q.Push(12);
	q.Output();
	return 0;
}
