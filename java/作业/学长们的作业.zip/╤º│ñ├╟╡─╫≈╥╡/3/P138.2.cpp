#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int times=0;
void f(int n,vector<int> v)
{
	for(int i=1;i<=times;i++)
	{
		if(find(v.begin(),v.end(),i)==v.end())
		{
			vector<int> temp=v;
			temp.push_back(i);
			if(n==1)
			{
				for(vector<int>::iterator i=temp.begin();i!=temp.end();i++)
					cout<<*i<<' ';
				cout<<endl;
				return;
			}
			f(n-1,temp);
		}
	}
}

int main()
{
	vector<int> all;
	cout<<"n=3:"<<endl;
	times=3;
	all.push_back(1);
	all.push_back(2);
	all.push_back(3);
	f(3,vector<int>());
	cout<<endl;
	cout<<"n=4:"<<endl;
	times=4;
	all.push_back(4);
	f(4,vector<int>());
	return 0;
}