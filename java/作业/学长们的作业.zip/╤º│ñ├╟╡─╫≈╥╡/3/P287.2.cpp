#include <iostream>
#include "P287.2.h"
using namespace std;

MinHeap::MinHeap(int theCapacity)
{
	if(theCapacity<1)
		throw "Capacity must be >=1";
	capacity=theCapacity;
	heapSize=0;
	heap=new int[capacity+1];
}

MinHeap::~MinHeap()
{
	delete heap;
}

bool MinHeap::IsEmpty() const
{
	return heapSize==0;
}

const int& MinHeap::Top() const
{
	return heap[1];
}

void MinHeap::ChangeSize1D(int* &a, const int oldSize,const int newSize)
{
    if(newSize < 0) 
		throw "New length must be >= 0";

    int* temp = new int[newSize];
    int number = min(oldSize,newSize);

    copy(a,a+number,temp);
    delete[] a;
    a=temp;
}

void MinHeap::Push(const int& v)
{
	if(heapSize==capacity)
	{
		ChangeSize1D(heap,capacity,2*capacity);
		capacity*=2;
	}
	int currentNode=++heapSize;
	while(currentNode!=1 && heap[currentNode/2]>v)
	{
		heap[currentNode]=heap[currentNode/2];
		currentNode/=2;
	}
	heap[currentNode]=v;
}

void MinHeap::Pop()
{
	if(IsEmpty())
		throw "Heap is empty. Cannot delete.";
	heap[1]=0;
	int lastE=heap[heapSize--];
	int currentNode=1;
	int child=2;
	while(child<=heapSize)
	{
		if(child<heapSize && heap[child]<heap[child+1])
			child++;
		if(lastE<=heap[child])
			break;
		heap[currentNode]=heap[child];
		currentNode=child;
		child*=2;
	}
	heap[currentNode]=lastE;
}

void MinHeap::Output()
{
	for(int i=1;i<=heapSize;i++)
		cout<<heap[i]<<' ';
	cout<<endl;
}

int main()
{
	MinHeap h;
	for(int i=0;i<5;i++)
		h.Push(5-i);
	h.Output();
	return 0;
}