#include<iostream>
#include<map>
using namespace std;

#ifndef TREE_H
#define TREE_H

class Node
{
	friend class WinnerTree;
	friend class LoserTree;
public:
	Node(int d=0,Node* l=0,Node* r=0,Node* p=0):data(d),left(l),right(r),parent(p){}
private:
	int data;
	Node* left;
	Node* right;
	Node* parent;
};

class WinnerTree
{
public:
	WinnerTree(int* all,int n);
	void Delete(Node* n);
	Node* GetRoot()
	{return root;}
	~WinnerTree();
private:
	Node* root;
	Node** bottom;
	int height;
};

class LoserTree
{
public:
	LoserTree(WinnerTree &t);
	void Switch(Node* oldtree, Node* &newtree,Node* parent);
	void Delete(Node* n);
	~LoserTree();
private:
	Node* root;
	Node* winner;
};
#endif