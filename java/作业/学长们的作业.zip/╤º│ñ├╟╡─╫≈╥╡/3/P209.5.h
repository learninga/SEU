#include<iostream>
using namespace std;

#ifndef POLYNOMIALS_H
#define POLYNOMIALS_H

class Polynomial;

class Node
{
	friend class Polynomial;
	friend istream& operator>>(istream& is,Polynomial& x);
	friend ostream& operator<<(ostream& is,Polynomial& x);
public:
	Node(int c,int e):coef(c),exp(e),link(NULL){}
private:
	int coef;
	int exp;
	Node* link;
};

class Polynomial
{
	friend istream& operator>>(istream& is,Polynomial& x);
	friend ostream& operator<<(ostream& is,Polynomial& x);
public:
	Polynomial();
	Polynomial(const Polynomial& a);
	const Polynomial& operator=(const Polynomial& a);
	Polynomial operator+(const Polynomial& b);
	Polynomial operator-(const Polynomial& b);
	Polynomial operator*(const Polynomial& b);
	float Evaluate(float x)const;
	void InsertBack(int coef,int exp);
private:
	Node* header;
	Node* last;
};

#endif