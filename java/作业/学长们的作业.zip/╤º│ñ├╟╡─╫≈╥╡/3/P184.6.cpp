#include<iostream>
#include"P184.6.h"
using namespace std;

void Chain::AddLeft(int v)
{
	if(l==NULL)
	{
		l=new ChainNode(v);
	}
	else
	{
		ChainNode* last=l;
		while(last->link!=NULL)
			last=last->link;
		last->link=new ChainNode(v);
	}
}

void Chain::AddRight(int v)
{
	if(r==NULL)
	{
		r=new ChainNode(v);
	}
	else
	{
		ChainNode* last=r;
		while(last->link!=NULL)
			last=last->link;
		last->link=new ChainNode(v);
	}
}

void Chain::MoveToRight(int n)
{
	int count=0;
	while(r->link!=NULL && count<n)
	{
		ChainNode* ltemp=l;
		l=r;
		r=r->link;
		l->link=ltemp;		
		count++;
	}
	if(count!=n)
	{
		l=r;
		r=0;
	}
}

void Chain::MoveToLeft(int n)
{
	int count=0;
	while(l->link!=NULL && count<n)
	{
		ChainNode* rtemp=r;
		r=l;
		l=l->link;
		r->link=rtemp;		
		count++;
	}
	if(count!=n)
	{
		r=l;
		l=0;
	}
}

int main()
{
	Chain c;
	c.AddLeft(3);
	c.AddLeft(2);
	c.AddLeft(1);
	c.AddRight(4);
	c.AddRight(5);
	c.MoveToRight(1);
	c.MoveToLeft(2);
	return 0;
}
