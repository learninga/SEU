#include <iostream>

#ifndef STRING_H
#define STRING_H

class String
{
public:
	String(char* c);
	~String()
	{delete[] str;}
	void Frequency();
	void FailureFunction();
	void FailureFunction2();
	int FastFind(String &pat);
private:
	char* str;
	int length;
	int* f;
};

#endif