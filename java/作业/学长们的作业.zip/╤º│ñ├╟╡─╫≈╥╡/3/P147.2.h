#include <iostream>

#ifndef QUEUE_H
#define QUEUE_H

enum Operation{pop,push};

template<class T>
class Queue
{
public:
	Queue(int queueCapacity=10);
	~Queue()
	{delete[] queue;}
	bool IsEmpty() const
	{return (front==rear && lastOp==pop);}
	bool IsFull() const
	{return (front==rear && lastOp==push);}
	T& Front() const
	{
		if(IsEmpty())
			throw "Queue is empty. No front element.";
		return queue[(front+1)%capacity];
	}
	T& Rear() const
	{
		if(IsEmpty())
			throw "Queue is empty. No rear element.";
		return queue[rear];
	}
	void Push(const T& item);
	void Pop();
	void Output();
	void Split(Queue &a,Queue &b);
private:
	T* queue;
	int front;
	int rear;
	int capacity;
	int lastOp;
};

#endif