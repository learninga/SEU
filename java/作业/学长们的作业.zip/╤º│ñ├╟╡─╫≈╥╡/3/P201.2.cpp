#include<iostream>
#include"P201.2.h"
using namespace std;

int main()
{
	LinkedQueue<int> lq;
	lq.Push(1);
	lq.Push(2);
	lq.Push(3);
	lq.Push(4);
	lq.Push(5);
	lq.Pop();
	lq.Pop();
	lq.Output();
	cout<<endl;
	return 0;
}
