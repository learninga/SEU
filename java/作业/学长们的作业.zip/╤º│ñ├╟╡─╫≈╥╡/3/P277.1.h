#include<iostream>
#include<stack>
using namespace std;

#ifndef TBTREE_H
#define TBTREE_H

class ThreadedTree;

class ThreadedNode
{
	friend class ThreadedTree;
public:
	ThreadedNode(int d):data(d),leftChild(NULL),rightChild(NULL),leftThread(true),rightThread(true){}
	void SetLeft(ThreadedNode* t);
	void SetRight(ThreadedNode* t);
	ThreadedNode* GetLeft();
	ThreadedNode* GetRight();
private:
	int data;
	ThreadedNode *leftChild;
	ThreadedNode *rightChild;
	bool leftThread;
	bool rightThread;
};

class ThreadedTree
{
public:
	ThreadedTree(ThreadedNode* n):root(n){}
	ThreadedNode* GetRoot();
	void InsertLeft(ThreadedNode *s,ThreadedNode *r);
	ThreadedNode* InorderSucc(ThreadedNode* r);
private:
	ThreadedNode *root;
};

#endif