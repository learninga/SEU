#include<iostream>
#include<stack>
using namespace std;

#ifndef TREE_H
#define TREE_H

class Tree;
class TreeIterator;

class TreeNode
{
	friend class Tree;
	friend class TreeIterator;
public:
	TreeNode(int d):data(d),leftChild(NULL),rightChild(NULL){}
	void SetLeft(TreeNode* t);
	void SetRight(TreeNode* t);
private:
	int data;
	TreeNode *leftChild;
	TreeNode *rightChild;
};

class TreeIterator
{
public:
	TreeIterator(TreeNode* c):currentNode(c){};
	int Get(int* n);
	int* Next();
private:
	TreeNode* currentNode;
	stack<TreeNode*> s;
};

class Tree
{
public:
	Tree():root(NULL){}
	TreeNode* GetRoot();
private:
	TreeNode *root;
};

#endif