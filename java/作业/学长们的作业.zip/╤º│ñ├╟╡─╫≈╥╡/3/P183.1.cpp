#include<iostream>
#include"P183.1.h"
using namespace std;

void Chain::Add(int v)
{
	if(first==NULL)
		first=new ChainNode(v);
	else
	{
		ChainNode* last=first;
		while(last->link!=NULL)
			last=last->link;
		last->link=new ChainNode(v);
	}
}

int Chain::Length()
{
	int count=0;
	ChainNode* last=first;
	while(last!=NULL)
	{
			last=last->link;
			count++;
	}
	return count;
}

int main()
{
	Chain c;
	c.Add(1);
	c.Add(2);
	c.Add(3);
	cout<<"Length of the chain: "<<c.Length()<<endl;
	return 0;
}
