#include <iostream>
using namespace std;

void QuickSort(int *a,const int left,const int right)
{
	static int times=0;
	if(left<right)
	{
		int i=left;
		int j=right+1;
		int pivot=a[left];
		do
		{
			do {i++;times++;}while(a[i]<pivot);
			do {j--;times++;}while(a[j]>pivot);
			if(i<j)
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			times++;
		}while(i<j);
		int temp=a[left];
		a[left]=a[j];
		a[j]=temp;

		for(int i=0;i<11;i++)
		{
			if(i==left)
				cout<<'[';
			cout<<a[i];
			if(i==right)
				cout<<"]  ";
			else
				cout<<"  ";
		}
		cout<<left<<"  "<<right<<"  times: "<<times<<endl;

		QuickSort(a,left,j-1);
		QuickSort(a,j+1,right);
	}
}

int main()
{
	int nums[]={1,2,3,4,5,6,7,8,9,10,11};
	for(int i=0;i<11;i++)
		cout<<"R"<<i<<' ';
	cout<<"left right"<<endl;
	QuickSort(nums,0,10);
	return 0;
}