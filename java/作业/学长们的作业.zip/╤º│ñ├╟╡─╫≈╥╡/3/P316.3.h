#include<iostream>
#include<map>
using namespace std;

#ifndef SET_H
#define SET_H

class Sets
{
public:
	Sets(int numberOfElements);
	void SimpleUnion(int i,int j);
	int SimpleFind(int i);
	void WeightedUnion(int i,int j);
	int CollapsingFind(int i);
	void SetParent(int* p)
	{parent=p;}
	int* GetParent()
	{return parent;}
private:
	int *parent;
	int n;
};

#endif