#include <iostream>

#ifndef DBLLIST_H
#define DBLLIST_H

class DblList;

class DblListNode
{
public:
	friend class DblList;
private:
	int data;
	DblListNode *left,*right;
};

class DblList
{
public:
	DblList():first(NULL),last(NULL){}
	void Insert(int v);
	void Output();
	void Concatenate(DblList m);
private:
	DblListNode *first;
	DblListNode *last;
};

#endif