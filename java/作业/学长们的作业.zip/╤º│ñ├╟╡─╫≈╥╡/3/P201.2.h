#include <iostream>

#ifndef LINKEDQUEUE_H
#define LINKEDQUEUE_H

template<class T>
class LinkedQueue;

template<class T>
class ChainNode
{
public:
	friend class LinkedQueue<T>;
	ChainNode(T d=0):data(d),link(NULL){}
private:
	T data;
	ChainNode<T> *link;
};

template<class T>
class LinkedQueue
{
public:
	LinkedQueue(){front=0;rear=0;length=0;}
	void Push(T v)
	{
		if(IsEmpty())
			front=rear=new ChainNode<T>(v);
		else
			rear=rear->link=new ChainNode<T>(v);
		length++;
	}
	void Pop()
	{
		if(IsEmpty())
			throw "Queue is empty. Cannot delete.";
		ChainNode<T> *delNode=front;
		front=front->link;
		delete delNode;
		length--;
	}
	bool IsEmpty()
	{return front==NULL;}
	void Output()
	{
		ChainNode<T>* current=front;
		while(current!=NULL)
		{
			std::cout<<current->data<<' ';
			current=current->link;
		}
	}
private:
	ChainNode<T> *front;
	ChainNode<T> *rear;
	int length;
};

#endif