#include<iostream>
#include<map>
#include"P119.7.h"
using namespace std;

String::String(char* c)
{
	length=0;
	while(c[length++]!='\0');
	str=new char[--length];
	f=new int[length];
	for(int i=0;i<length;i++)
		str[i]=c[i];
}

void String::Frequency()
{
	map<char,int> m;
	for(int i=0;i<length;i++)
		m[str[i]]++;
	for(map<char,int>::iterator i=m.begin();i!=m.end();i++)
		cout<<i->first<<": "<<i->second<<"\t"<<i->second/(float)length<<endl;
}

void String::FailureFunction()
{
	f[0]=-1;
	for (int j=1; j<length; j++) 
	{
		int i=f[j-1];
		while ((*(str+j)!=*(str+i+1)) && (i>=0)) 
			i=f[i];
		*(str+j)==*(str+i+1) ? f[j]=i+1 : f[j]=-1;
	}
	for(int i=0;i<length;i++)
		cout<<f[i]<<' ';
	cout<<endl;
}

int main()
{
	String s1("aaaab");
	s1.FailureFunction();
	String s2("ababaa");
	s2.FailureFunction();
	String s3("abaabaabb");
	s3.FailureFunction();
	return 0;
}