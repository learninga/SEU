#include <iostream>
#include "P267.6.h"
using namespace std;

void TreeNode::SetLeft(TreeNode* t)
{
	leftChild=t;
}

void TreeNode::SetRight(TreeNode* t)
{
	rightChild=t;
}

TreeNode* TreeNode::GetLeft()
{
	return leftChild;
}

TreeNode* TreeNode::GetRight()
{
	return rightChild;
}

TreeNode* Tree::GetRoot()
{
	return root;
}

void Tree::Visit(TreeNode* n)
{
	cout<<n->data<<endl;
}

void Tree::NonrecPreorder()
{
	stack<TreeNode*> s;
	TreeNode *currentNode=root;
	while(1)
	{
		while(currentNode)
		{
			Visit(currentNode);
			s.push(currentNode);
			currentNode=currentNode->leftChild;
		}
		if(s.empty())
			return;
		currentNode=s.top();
		s.pop();
		currentNode=currentNode->rightChild;
	}
}

int main()
{
	Tree t(new TreeNode(2));
	TreeNode* root=t.GetRoot();
	root->SetLeft(new TreeNode(1));
	root->SetRight(new TreeNode(3));
	TreeNode* l=root->GetLeft();
	l->SetLeft(new TreeNode(4));
	l->SetRight(new TreeNode(5));
	t.NonrecPreorder();
	return 0;
}