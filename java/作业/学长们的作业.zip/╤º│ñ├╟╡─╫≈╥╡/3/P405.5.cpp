#include <iostream>
using namespace std;

struct Data
{
	int key;
	int num;
};

void QuickSort(Data *a,const int left,const int right)
{
	static int times=0;
	if(left<right)
	{
		int i=left;
		int j=right+1;
		int pivot=a[left].num;
		do
		{
			do {i++;}while(a[i].num<pivot);
			do {j--;}while(a[j].num>pivot);
			if(i<j)
			{
				Data temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			times++;
		}while(i<j);
		Data temp=a[left];
		a[left]=a[j];
		a[j]=temp;

		QuickSort(a,left,j-1);
		QuickSort(a,j+1,right);
	}
}

int main()
{
	Data nums[]={{1,1},{2,2},{3,2},{4,3},{5,4}};
	cout<<"Before:"<<endl;
	cout<<"Key: ";
	for(int i=0;i<5;i++)
		cout<<nums[i].key<<' ';
	cout<<endl;
	cout<<"Num: ";
	for(int i=0;i<5;i++)
		cout<<nums[i].num<<' ';
	cout<<endl;
	QuickSort(nums,0,4);
	cout<<"After:"<<endl;
	cout<<"Key: ";
	for(int i=0;i<5;i++)
		cout<<nums[i].key<<' ';
	cout<<endl;
	cout<<"Num: ";
	for(int i=0;i<5;i++)
		cout<<nums[i].num<<' ';
	cout<<endl;
	return 0;
}