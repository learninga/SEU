#include <iostream>
#include "P267.10.h"
using namespace std;

int main()
{
	TreeNode<int>* root;
	root=new TreeNode<int>(2);
	root->SetLeft(new TreeNode<int>(1));
	root->SetRight(new TreeNode<int>(3));
	BinaryTree<int> t(root);

	PreorderIterator<int> preiter(root);
	int* now=preiter.Next();
	while(now!=NULL)
	{
		cout<<preiter.Get(now)<<endl;
		now=preiter.Next();
	}
	cout<<endl;

	InorderIterator<int> initer(root);
	now=initer.Next();
	while(now!=NULL)
	{
		cout<<initer.Get(now)<<endl;
		now=initer.Next();
	}
	cout<<endl;

	PostorderIterator<int> postiter(root);
	now=postiter.Next();
	while(now!=NULL)
	{
		cout<<postiter.Get(now)<<endl;
		now=postiter.Next();
	}
	cout<<endl;

	LevelorderIterator<int> leveliter(root);
	now=leveliter.Next();
	while(now!=NULL)
	{
		cout<<leveliter.Get(now)<<endl;
		now=leveliter.Next();
	}
	cout<<endl;
	return 0;
}