#include<iostream>
#include"P194.4.h"
using namespace std;

void Chain::Add(int v)
{
	if(first==NULL)
	{
		first=new ChainNode(v);
		last=first;
	}
	else
	{
		ChainNode* item=new ChainNode(v);
		last->link=item;
		last=item;
	}
	length++;
}

ostream& operator<<(ostream& out,Chain& c)
{
	ChainNode* current=c.first;
	while(current!=NULL)
	{
		out<<current->data<<' ';
		current=current->link;
	}
	return out;
}

int Chain::Compute()
{
	ChainNode* a=first;
	ChainNode* b=first;
	for(int i=0;i<5;i++)
		b=b->link;
	int result=0;
	while(b!=NULL)
	{
		result+=a->data*b->data;
		a=a->link;
		b=b->link;
	}
	return result;
}

int main()
{
	Chain c;
	c.Add(1);
	c.Add(2);
	c.Add(3);
	c.Add(4);
	c.Add(5);
	c.Add(6);
	c.Add(7);
	c.Add(8);
	cout<<"The result is: "<<c.Compute()<<endl;
	return 0;
}
