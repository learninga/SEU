#include <iostream>
#include "P267.4.h"
using namespace std;

int* TreeIterator::Next()
{
	while(currentNode)
	{
		s.push(currentNode);
		currentNode=currentNode->leftChild;
	}
	if(s.empty())
		return 0;
	currentNode=s.top();
	s.pop();
	int& temp=currentNode->data;
	currentNode=currentNode->rightChild;
	return &temp;
}

int TreeIterator::Get(int* n)
{
	return *n;
}

void TreeNode::SetLeft(TreeNode* t)
{
	leftChild=t;
}

void TreeNode::SetRight(TreeNode* t)
{
	rightChild=t;
}

TreeNode* Tree::GetRoot()
{
	return root;
}

int main()
{
	Tree t;
	TreeNode* root=t.GetRoot();
	root=new TreeNode(2);
	root->SetLeft(new TreeNode(1));
	root->SetRight(new TreeNode(3));
	TreeIterator iter(root);
	int* now=iter.Next();
	while(now!=NULL)
	{
		cout<<iter.Get(now)<<endl;
		now=iter.Next();
	}
	return 0;
}