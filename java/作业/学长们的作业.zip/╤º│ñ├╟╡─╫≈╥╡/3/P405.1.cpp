#include <iostream>
using namespace std;

void QuickSort(int *a,const int left,const int right)
{
	if(left<right)
	{
		int i=left;
		int j=right+1;
		int pivot=a[left];
		do
		{
			do i++;while(a[i]<pivot);
			do j--;while(a[j]>pivot);
			if(i<j)
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}while(i<j);
		int temp=a[left];
		a[left]=a[j];
		a[j]=temp;

		for(int i=0;i<11;i++)
		{
			if(i==left)
				cout<<'[';
			cout<<a[i];
			if(i==right)
				cout<<"]  ";
			else
				cout<<"  ";
		}
		cout<<left<<"  "<<right<<endl;
		QuickSort(a,left,j-1);
		QuickSort(a,j+1,right);
	}
}

int main()
{
	int nums[]={12,2,16,30,8,28,4,10,20,6,18};
	for(int i=0;i<11;i++)
		cout<<"R"<<i<<' ';
	cout<<"left right"<<endl;
	QuickSort(nums,0,10);
	return 0;
}